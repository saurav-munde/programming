/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
public class Main
{   
    public static int sum(int input[]) {
        return sumRecursive(input, input.length - 1);
    }

    private static int sumRecursive(int input[], int lastIndex) {
        // Base case: If the array is empty (index is -1), return 0.
        if (lastIndex < 0) {
            return 0;
        }

        // Recursive case: Add the last element to the sum of the rest of the elements.
        int currentElement = input[lastIndex];
        int sumOfRest = sumRecursive(input, lastIndex - 1);
        
        return currentElement + sumOfRest;
    }

    public static void main(String[] args) {
        int[] array1 = {9, 8, 9};
        int[] array2 = {4, 2, 1};

        System.out.println("Sample Output 1: " + sum(array1)); // Output: 26
        System.out.println("Sample Output 2: " + sum(array2)); // Output: 7
    }
}
